"""
AWS Lambda: Supabase to SQL Server Bridge Test
Receives data via API Gateway and inserts into SQL Server on EC2
"""
import json
import pymssql
import os
from datetime import datetime

# SQL Server connection config from environment variables
DB_CONFIG = {
    'server': os.environ.get('DB_SERVER', '172.31.66.246'),
    'port': os.environ.get('DB_PORT', '1433'),
    'user': os.environ.get('DB_USER', 'dbox'),
    'password': os.environ.get('DB_PASSWORD', 'Monday123$'),
    'database': os.environ.get('DB_NAME', 'LCMD_DB')
}

def lambda_handler(event, context):
    """
    Main Lambda handler
    Expects JSON body with test data to insert
    """
    print(f"Event received: {json.dumps(event)}")

    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Content-Type': 'application/json'
    }

    # Handle OPTIONS preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {'statusCode': 200, 'headers': headers, 'body': ''}

    conn = None

    try:
        # Parse request body
        body = event.get('body', '{}')
        if isinstance(body, str):
            body = json.loads(body)

        print(f"Parsed body: {body}")

        # Extract test data from payload
        test_name = body.get('test_name', 'default_test')
        test_value = body.get('test_value', 'no_value_provided')
        source = body.get('source', 'api_gateway')

        # Connect to SQL Server
        print(f"Connecting to SQL Server: {DB_CONFIG['server']}...")
        conn = pymssql.connect(
            server=DB_CONFIG['server'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database']
        )
        cursor = conn.cursor()
        print("Connected to SQL Server successfully")

        # Create test table if it doesn't exist
        create_table_sql = """
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='supabase_bridge_test' AND xtype='U')
        CREATE TABLE supabase_bridge_test (
            id INT IDENTITY(1,1) PRIMARY KEY,
            test_name NVARCHAR(255) NOT NULL,
            test_value NVARCHAR(MAX),
            source NVARCHAR(100),
            created_at DATETIME DEFAULT GETDATE(),
            payload_json NVARCHAR(MAX)
        )
        """
        cursor.execute(create_table_sql)
        conn.commit()
        print("Table check/creation complete")

        # Insert test data
        insert_sql = """
        INSERT INTO supabase_bridge_test (test_name, test_value, source, payload_json)
        VALUES (%s, %s, %s, %s)
        """
        payload_json = json.dumps(body)
        cursor.execute(insert_sql, (test_name, test_value, source, payload_json))
        conn.commit()

        # Get the inserted ID
        cursor.execute("SELECT @@IDENTITY")
        inserted_id = cursor.fetchone()[0]

        print(f"Inserted row with ID: {inserted_id}")

        # Get row count
        cursor.execute("SELECT COUNT(*) FROM supabase_bridge_test")
        total_rows = cursor.fetchone()[0]

        cursor.close()
        conn.close()

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'message': 'Data inserted into SQL Server successfully',
                'inserted_id': int(inserted_id) if inserted_id else None,
                'total_rows_in_table': total_rows,
                'data': {
                    'test_name': test_name,
                    'test_value': test_value,
                    'source': source
                },
                'timestamp': datetime.utcnow().isoformat()
            })
        }

    except Exception as e:
        print(f"Error: {str(e)}")

        if conn:
            try:
                conn.close()
            except:
                pass

        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'success': False,
                'error': str(e),
                'timestamp': datetime.utcnow().isoformat()
            })
        }
